package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CheckoutDialog
import com.example.ui.components.OrderSuccessDialog
import com.example.ui.components.ProductDetailDialog
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SaffronSecondary
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.ShopViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class NavigationTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KhalfanFoodApp()
            }
        }
    }
}

@Composable
fun KhalfanFoodApp(
    shopViewModel: ShopViewModel = viewModel(),
    adminViewModel: AdminViewModel = viewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }

    // Shop ViewModel state
    val displayedProducts by shopViewModel.displayedProducts.collectAsStateWithLifecycle()
    val searchQuery by shopViewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by shopViewModel.selectedCategory.collectAsStateWithLifecycle()
    val currentSort by shopViewModel.sortOption.collectAsStateWithLifecycle()
    val cartItems by shopViewModel.cartItems.collectAsStateWithLifecycle()
    val allOrders by shopViewModel.allOrders.collectAsStateWithLifecycle()
    val storeConfig by shopViewModel.storeConfig.collectAsStateWithLifecycle()
    val selectedProduct by shopViewModel.selectedProduct.collectAsStateWithLifecycle()
    val isCheckoutOpen by shopViewModel.isCheckoutOpen.collectAsStateWithLifecycle()
    val placedOrder by shopViewModel.placedOrder.collectAsStateWithLifecycle()

    // Admin ViewModel state
    val isAdminAuthenticated by adminViewModel.isAuthenticated.collectAsStateWithLifecycle()
    val dashboardStats by adminViewModel.dashboardStats.collectAsStateWithLifecycle()
    val adminProducts by adminViewModel.allProducts.collectAsStateWithLifecycle()
    val adminOrders by adminViewModel.orders.collectAsStateWithLifecycle()
    val adminSelectedFilter by adminViewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    val editingProduct by adminViewModel.editingProduct.collectAsStateWithLifecycle()
    val isAddProductOpen by adminViewModel.isAddProductDialogOpen.collectAsStateWithLifecycle()
    val selectedOrderForDispatch by adminViewModel.selectedOrderForDispatch.collectAsStateWithLifecycle()

    // Snackbars / Toast collection
    LaunchedEffect(Unit) {
        launch {
            shopViewModel.toastEvent.collectLatest { msg ->
                snackbarHostState.showSnackbar(msg)
            }
        }
        launch {
            adminViewModel.toastEvent.collectLatest { msg ->
                snackbarHostState.showSnackbar(msg)
            }
        }
    }

    // Back handler: return to Home tab if on sub-tabs
    BackHandler(enabled = selectedTabIndex != 0) {
        selectedTabIndex = 0
    }

    val tabs = listOf(
        NavigationTab("Shop", Icons.Filled.Storefront, Icons.Outlined.Storefront, "nav_shop"),
        NavigationTab("Cart", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart, "nav_cart"),
        NavigationTab("Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "nav_orders"),
        NavigationTab("Admin", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings, "nav_admin")
    )

    val cartItemCount = cartItems.sumOf { it.quantity }
    val subtotal = cartItems.sumOf { it.product.price * it.quantity }
    val deliveryFee = if (subtotal >= storeConfig.freeDeliveryThreshold) 0.0 else storeConfig.deliveryFee
    val grandTotal = subtotal + deliveryFee

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    val isSelected = selectedTabIndex == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTabIndex = index },
                        icon = {
                            if (tab.title == "Cart" && cartItemCount > 0) {
                                BadgedBox(badge = {
                                    Badge(
                                        containerColor = SaffronSecondary
                                    ) {
                                        Text("$cartItemCount")
                                    }
                                }) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.title
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTabIndex) {
                0 -> HomeScreen(
                    products = displayedProducts,
                    searchQuery = searchQuery,
                    selectedCategory = selectedCategory,
                    currentSort = currentSort,
                    cartItemCount = cartItemCount,
                    announcementText = storeConfig.announcement,
                    onSearchQueryChange = shopViewModel::onSearchQueryChanged,
                    onCategorySelect = shopViewModel::onCategorySelected,
                    onSortOptionSelect = shopViewModel::onSortOptionChanged,
                    onProductClick = shopViewModel::onProductSelected,
                    onAddToCart = { shopViewModel.addToCart(it, 1) },
                    onNavigateToCart = { selectedTabIndex = 1 }
                )
                1 -> CartScreen(
                    cartItems = cartItems,
                    deliveryFee = storeConfig.deliveryFee,
                    freeDeliveryThreshold = storeConfig.freeDeliveryThreshold,
                    onUpdateQuantity = shopViewModel::updateCartQuantity,
                    onRemoveItem = shopViewModel::removeFromCart,
                    onCheckoutClick = { shopViewModel.openCheckout(true) },
                    onStartShoppingClick = { selectedTabIndex = 0 }
                )
                2 -> OrdersScreen(
                    orders = allOrders,
                    whatsappNumber = storeConfig.whatsappNumber,
                    onStartShopping = { selectedTabIndex = 0 }
                )
                3 -> AdminScreen(
                    isAuthenticated = isAdminAuthenticated,
                    dashboardStats = dashboardStats,
                    products = adminProducts,
                    orders = adminOrders,
                    storeConfig = storeConfig,
                    selectedFilter = adminSelectedFilter,
                    editingProduct = editingProduct,
                    isAddProductOpen = isAddProductOpen,
                    selectedOrderForDispatch = selectedOrderForDispatch,
                    onVerifyPin = adminViewModel::verifyPin,
                    onLogout = adminViewModel::logout,
                    onFilterChange = adminViewModel::onStatusFilterChanged,
                    onOpenAddProduct = adminViewModel::openAddProductDialog,
                    onSetEditingProduct = adminViewModel::setEditingProduct,
                    onSaveProduct = adminViewModel::saveProduct,
                    onToggleStock = adminViewModel::toggleProductStock,
                    onDeleteProduct = adminViewModel::deleteProduct,
                    onSetOrderForDispatch = adminViewModel::setOrderForDispatch,
                    onDispatchOrder = adminViewModel::dispatchOrder,
                    onUpdateOrderStatus = adminViewModel::updateOrderStatus,
                    onUpdateStoreConfig = adminViewModel::updateStoreConfig
                )
            }
        }
    }

    // Product Detail Dialog
    selectedProduct?.let { product ->
        ProductDetailDialog(
            product = product,
            whatsappNumber = storeConfig.whatsappNumber,
            onDismiss = { shopViewModel.onProductSelected(null) },
            onAddToCart = { prod, qty ->
                shopViewModel.addToCart(prod, qty)
            }
        )
    }

    // Checkout Dialog
    if (isCheckoutOpen) {
        CheckoutDialog(
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            grandTotal = grandTotal,
            onDismiss = { shopViewModel.openCheckout(false) },
            onConfirmOrder = { name, phone, city, address, notes, payment ->
                shopViewModel.placeOrder(name, phone, city, address, notes, payment)
            }
        )
    }

    // Order Success Dialog
    placedOrder?.let { order ->
        OrderSuccessDialog(
            order = order,
            whatsappNumber = storeConfig.whatsappNumber,
            onDismiss = { shopViewModel.dismissOrderConfirmation() },
            onViewOrders = {
                shopViewModel.dismissOrderConfirmation()
                selectedTabIndex = 2
            }
        )
    }
}
