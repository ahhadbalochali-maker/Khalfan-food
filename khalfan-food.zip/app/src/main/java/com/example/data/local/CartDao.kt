package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CartItemEntity
import com.example.data.model.CartItemWithProduct
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
    @Query("""
        SELECT cart_items.id AS cartId, cart_items.quantity AS quantity, products.* 
        FROM cart_items 
        INNER JOIN products ON cart_items.productId = products.id 
        ORDER BY cart_items.addedAt DESC
    """)
    fun getCartWithProducts(): Flow<List<CartItemWithProduct>>

    @Query("SELECT * FROM cart_items WHERE productId = :productId LIMIT 1")
    suspend fun getCartItemByProduct(productId: Long): CartItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity): Long

    @Update
    suspend fun updateCartItem(item: CartItemEntity)

    @Query("UPDATE cart_items SET quantity = :quantity WHERE id = :cartId")
    suspend fun updateQuantity(cartId: Long, quantity: Int)

    @Query("DELETE FROM cart_items WHERE id = :cartId")
    suspend fun deleteCartItem(cartId: Long)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}
