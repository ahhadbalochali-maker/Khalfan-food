package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.OrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE orderId = :orderId")
    suspend fun getOrderById(orderId: String): OrderEntity?

    @Query("SELECT * FROM orders WHERE status = :status ORDER BY createdAt DESC")
    fun getOrdersByStatus(status: String): Flow<List<OrderEntity>>

    @Query("SELECT COUNT(*) FROM orders")
    suspend fun getOrderCount(): Int

    @Query("SELECT SUM(grandTotal) FROM orders WHERE status != 'Cancelled'")
    suspend fun getTotalRevenue(): Double?

    @Query("SELECT COUNT(*) FROM orders WHERE status = 'Pending' OR status = 'Processing'")
    suspend fun getPendingOrdersCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :newStatus WHERE orderId = :orderId")
    suspend fun updateStatus(orderId: String, newStatus: String)

    @Query("UPDATE orders SET courierName = :courier, trackingNumber = :tracking, status = 'Dispatched' WHERE orderId = :orderId")
    suspend fun markAsDispatched(orderId: String, courier: String, tracking: String)
}
