package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey
    val orderId: String, // e.g. "KF-4829"
    val customerName: String,
    val customerPhone: String,
    val customerCity: String, // Karachi, Lahore, Islamabad, etc.
    val customerAddress: String,
    val specialNotes: String = "",
    val itemsSummary: String, // e.g. "Pure Desi Ghee (1 Kg) x 2, Beri Honey (500g) x 1"
    val itemsTotal: Double,
    val deliveryFee: Double,
    val grandTotal: Double,
    val paymentMethod: String, // "Cash on Delivery (COD)", "JazzCash / EasyPaisa", "Bank Transfer"
    val status: String = "Pending", // "Pending", "Confirmed", "Processing", "Dispatched", "Delivered", "Cancelled"
    val courierName: String = "", // "TCS", "Leopard Courier", "Trax Logistics"
    val trackingNumber: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
