package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // e.g. "Desi Ghee", "Pure Honey", "Spices", "Dry Fruits", "Rice & Grains", "Pickles"
    val price: Double, // in PKR (Rs.)
    val originalPrice: Double? = null,
    val weightUnit: String, // e.g. "1 Kg", "500g Jar", "250g Pouch"
    val imageUrl: String = "", // custom url or resource tag
    val description: String,
    val inStock: Boolean = true,
    val stockQuantity: Int = 50,
    val isFeatured: Boolean = false,
    val rating: Float = 4.8f,
    val reviewCount: Int = 36,
    val badge: String? = null // e.g. "Pure Desi", "Organic", "Bestseller"
)
