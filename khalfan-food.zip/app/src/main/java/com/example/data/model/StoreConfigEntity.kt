package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "store_config")
data class StoreConfigEntity(
    @PrimaryKey
    val id: Int = 1,
    val storeName: String = "Khalfan Food",
    val storePhone: String = "0312-3456789",
    val whatsappNumber: String = "+923123456789",
    val deliveryFee: Double = 250.0,
    val freeDeliveryThreshold: Double = 3000.0,
    val announcement: String = "🚚 All Pakistan Express Delivery | Free Shipping on orders over Rs. 3,000!",
    val adminPin: String = "1234",
    val isStoreOnline: Boolean = true
)
