package com.example.data.repository

import com.example.data.local.CartDao
import com.example.data.local.OrderDao
import com.example.data.local.ProductDao
import com.example.data.local.StoreConfigDao
import com.example.data.model.CartItemEntity
import com.example.data.model.CartItemWithProduct
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.StoreConfigEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class FoodShopRepository(
    private val productDao: ProductDao,
    private val cartDao: CartDao,
    private val orderDao: OrderDao,
    private val storeConfigDao: StoreConfigDao
) {
    // Products
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()

    fun getProductsByCategory(category: String): Flow<List<ProductEntity>> =
        if (category == "All") productDao.getAllProducts()
        else productDao.getProductsByCategory(category)

    suspend fun getProductById(id: Long): ProductEntity? = productDao.getProductById(id)

    suspend fun addProduct(product: ProductEntity): Long = productDao.insertProduct(product)

    suspend fun updateProduct(product: ProductEntity) = productDao.updateProduct(product)

    suspend fun deleteProduct(id: Long) = productDao.deleteProductById(id)

    // Cart
    val cartItems: Flow<List<CartItemWithProduct>> = cartDao.getCartWithProducts()

    suspend fun addToCart(productId: Long, qtyToAdd: Int = 1) {
        val existing = cartDao.getCartItemByProduct(productId)
        if (existing != null) {
            cartDao.updateQuantity(existing.id, existing.quantity + qtyToAdd)
        } else {
            cartDao.insertCartItem(CartItemEntity(productId = productId, quantity = qtyToAdd))
        }
    }

    suspend fun updateCartQuantity(cartId: Long, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.deleteCartItem(cartId)
        } else {
            cartDao.updateQuantity(cartId, newQuantity)
        }
    }

    suspend fun removeFromCart(cartId: Long) = cartDao.deleteCartItem(cartId)

    suspend fun clearCart() = cartDao.clearCart()

    // Orders
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()

    fun getOrdersByStatus(status: String): Flow<List<OrderEntity>> =
        if (status == "All") orderDao.getAllOrders()
        else orderDao.getOrdersByStatus(status)

    suspend fun getOrderById(orderId: String): OrderEntity? = orderDao.getOrderById(orderId)

    suspend fun placeOrder(order: OrderEntity) = orderDao.insertOrder(order)

    suspend fun updateOrderStatus(orderId: String, status: String) =
        orderDao.updateStatus(orderId, status)

    suspend fun markOrderDispatched(orderId: String, courier: String, tracking: String) =
        orderDao.markAsDispatched(orderId, courier, tracking)

    suspend fun getOrderStats(): Triple<Int, Double, Int> {
        val count = orderDao.getOrderCount()
        val revenue = orderDao.getTotalRevenue() ?: 0.0
        val pending = orderDao.getPendingOrdersCount()
        return Triple(count, revenue, pending)
    }

    // Config
    val storeConfig: Flow<StoreConfigEntity?> = storeConfigDao.getConfig()

    suspend fun getStoreConfigSync(): StoreConfigEntity =
        storeConfigDao.getConfigSync() ?: StoreConfigEntity()

    suspend fun updateStoreConfig(config: StoreConfigEntity) =
        storeConfigDao.updateConfig(config)

    // Prepopulate initial Pakistani food products and sample config
    suspend fun prepopulateIfNeeded() = withContext(Dispatchers.IO) {
        if (productDao.getProductCount() == 0) {
            val initialProducts = listOf(
                ProductEntity(
                    name = "Pure Desi Ghee (Khaalis Makhan)",
                    category = "Desi Ghee & Oils",
                    price = 2650.0,
                    originalPrice = 2950.0,
                    weightUnit = "1 Kg Tin",
                    description = "Traditional hand-churned grass-fed buffalo & cow butter cooked on low flame. Heavenly natural aroma and rich golden texture. 100% pure organic guarantee.",
                    badge = "Bestseller",
                    inStock = true,
                    stockQuantity = 45,
                    isFeatured = true,
                    rating = 4.9f,
                    reviewCount = 124
                ),
                ProductEntity(
                    name = "Wild Sidr Honey (Karak Beri Ka Shehad)",
                    category = "Honey & Sweeteners",
                    price = 2200.0,
                    originalPrice = 2500.0,
                    weightUnit = "1 Kg Glass Jar",
                    description = "100% Raw and unfiltered mountain Sidr (Beri) honey from Karak. Never heated, retains all natural pollens, vitamins, and healing enzymes.",
                    badge = "Pure Organic",
                    inStock = true,
                    stockQuantity = 30,
                    isFeatured = true,
                    rating = 5.0f,
                    reviewCount = 88
                ),
                ProductEntity(
                    name = "Shahi Special Degi Biryani Masala",
                    category = "Spices & Masalas",
                    price = 380.0,
                    originalPrice = 450.0,
                    weightUnit = "250g Pouch",
                    description = "Royal Karachi & Sindhi secret recipe with whole spices, black cardamom, star anise, mace, nutmeg, and Kashmiri red chili. Authentic restaurant aroma.",
                    badge = "Hot Blend",
                    inStock = true,
                    stockQuantity = 100,
                    isFeatured = true,
                    rating = 4.9f,
                    reviewCount = 62
                ),
                ProductEntity(
                    name = "Chitral Roasted Chilgoza (Pine Nuts)",
                    category = "Dry Fruits & Nuts",
                    price = 4800.0,
                    originalPrice = 5400.0,
                    weightUnit = "500g Vacuum Pack",
                    description = "Hand-harvested fresh mountain pine nuts in shell from Chitral valley. Roasted to crisp perfection with rich buttery natural crunch.",
                    badge = "New Harvest",
                    inStock = true,
                    stockQuantity = 22,
                    isFeatured = true,
                    rating = 4.8f,
                    reviewCount = 47
                ),
                ProductEntity(
                    name = "Super Kernel Basmati Rice (Khaalis Purana)",
                    category = "Rice & Grains",
                    price = 1650.0,
                    originalPrice = 1850.0,
                    weightUnit = "5 Kg Fabric Sack",
                    description = "Punjab extra-long grain aged Basmati rice. Doubles in length when steamed. Ideal for weddings, biryani, and pulao.",
                    badge = "Aged 2 Years",
                    inStock = true,
                    stockQuantity = 60,
                    isFeatured = true,
                    rating = 4.9f,
                    reviewCount = 95
                ),
                ProductEntity(
                    name = "Multani Asli Sohan Halwa (Pure Ghee)",
                    category = "Traditional Sweets",
                    price = 1250.0,
                    originalPrice = 1450.0,
                    weightUnit = "1 Kg Royal Tin",
                    description = "Famous Multan recipe crafted with pure desi ghee, sprouted wheat, pistachios, almonds, and walnuts. Rich, caramelized, and chewy.",
                    badge = "Original Multani",
                    inStock = true,
                    stockQuantity = 35,
                    isFeatured = true,
                    rating = 4.9f,
                    reviewCount = 83
                ),
                ProductEntity(
                    name = "Lahori Mixed Mango & Chili Achar",
                    category = "Pickles & Chutneys",
                    price = 490.0,
                    originalPrice = 550.0,
                    weightUnit = "1 Kg Jar",
                    description = "Authentic spicy Lahori pickle preserved in pure cold-pressed sarson (mustard) oil with raw green mango slices, garlic cloves, and fenugreek.",
                    badge = "In Pure Oil",
                    inStock = true,
                    stockQuantity = 75,
                    isFeatured = false,
                    rating = 4.8f,
                    reviewCount = 51
                ),
                ProductEntity(
                    name = "Peshawari Green Tea (Qehwa Special)",
                    category = "Tea & Beverages",
                    price = 420.0,
                    originalPrice = 500.0,
                    weightUnit = "250g Tin",
                    description = "Historic Peshawar Qissa Khwani Bazaar recipe. Whole green tea leaves blended with green cardamom and wild saffron threads.",
                    badge = "Cardamom Infused",
                    inStock = true,
                    stockQuantity = 80,
                    isFeatured = false,
                    rating = 4.9f,
                    reviewCount = 39
                ),
                ProductEntity(
                    name = "Kashmiri Pure Mogra Saffron (Zafran)",
                    category = "Spices & Masalas",
                    price = 1800.0,
                    originalPrice = 2100.0,
                    weightUnit = "2g Airtight Vial",
                    description = "Grade-A pure red saffron filaments from Pampore Kashmir. Unrivaled floral aroma and deep golden amber hue for sweets, tea, and rice.",
                    badge = "Pure Zafran",
                    inStock = true,
                    stockQuantity = 40,
                    isFeatured = true,
                    rating = 5.0f,
                    reviewCount = 74
                ),
                ProductEntity(
                    name = "Quetta Garland Figs (Injeer No. 1)",
                    category = "Dry Fruits & Nuts",
                    price = 1750.0,
                    originalPrice = 2000.0,
                    weightUnit = "500g Garland",
                    description = "Plump, sun-dried natural garland figs from Balochistan orchards. Packed with fiber and iron, delightfully soft and sweet.",
                    badge = "Sun-Dried",
                    inStock = true,
                    stockQuantity = 28,
                    isFeatured = false,
                    rating = 4.8f,
                    reviewCount = 29
                ),
                ProductEntity(
                    name = "Wood-Pressed Sarson Ka Tel (Mustard Oil)",
                    category = "Desi Ghee & Oils",
                    price = 850.0,
                    originalPrice = 950.0,
                    weightUnit = "1 Litre Bottle",
                    description = "Kachi Ghani cold-pressed mustard oil with full pungency and vital nutrients intact. Ideal for Pakistani frying, curries, and pickling.",
                    badge = "Kohlu Pressed",
                    inStock = true,
                    stockQuantity = 55,
                    isFeatured = false,
                    rating = 4.7f,
                    reviewCount = 31
                )
            )
            productDao.insertAll(initialProducts)
        }

        if (storeConfigDao.getConfigSync() == null) {
            storeConfigDao.insertConfig(
                StoreConfigEntity(
                    id = 1,
                    storeName = "Khalfan Food",
                    storePhone = "0312-3456789",
                    whatsappNumber = "+923123456789",
                    deliveryFee = 250.0,
                    freeDeliveryThreshold = 3000.0,
                    announcement = "🚚 All Pakistan Express Delivery | Free Delivery on Orders over Rs. 3,000!",
                    adminPin = "1234"
                )
            )
        }

        if (orderDao.getOrderCount() == 0) {
            val sampleOrders = listOf(
                OrderEntity(
                    orderId = "KF-7821",
                    customerName = "Bilal Ahmed",
                    customerPhone = "0301-7894561",
                    customerCity = "Lahore",
                    customerAddress = "House 42, Block G, Model Town, Lahore",
                    specialNotes = "Deliver in evening after 5 PM please",
                    itemsSummary = "Pure Desi Ghee (1 Kg Tin) x 1, Wild Sidr Honey (1 Kg) x 1",
                    itemsTotal = 4850.0,
                    deliveryFee = 0.0,
                    grandTotal = 4850.0,
                    paymentMethod = "Cash on Delivery (COD)",
                    status = "Dispatched",
                    courierName = "TCS Express",
                    trackingNumber = "TCS-982144320",
                    createdAt = System.currentTimeMillis() - 86400000L
                ),
                OrderEntity(
                    orderId = "KF-6912",
                    customerName = "Zainab Tariq",
                    customerPhone = "0321-4567890",
                    customerCity = "Karachi",
                    customerAddress = "Flat 302, Al-Razi Heights, Clifton Block 5, Karachi",
                    specialNotes = "Leave at gate reception if not available",
                    itemsSummary = "Chitral Roasted Chilgoza (500g) x 1",
                    itemsTotal = 4800.0,
                    deliveryFee = 0.0,
                    grandTotal = 4800.0,
                    paymentMethod = "JazzCash / EasyPaisa",
                    status = "Delivered",
                    courierName = "Leopard Courier",
                    trackingNumber = "LEO-77218394",
                    createdAt = System.currentTimeMillis() - 172800000L
                ),
                OrderEntity(
                    orderId = "KF-8304",
                    customerName = "Dr. Asad Raza",
                    customerPhone = "0333-5123987",
                    customerCity = "Islamabad",
                    customerAddress = "Sector F-7/2, Street 19, House 12, Islamabad",
                    specialNotes = "Handle glass jar carefully",
                    itemsSummary = "Wild Sidr Honey (1 Kg) x 1, Peshawari Qehwa Special x 2",
                    itemsTotal = 3040.0,
                    deliveryFee = 0.0,
                    grandTotal = 3040.0,
                    paymentMethod = "Cash on Delivery (COD)",
                    status = "Processing",
                    courierName = "Trax Logistics",
                    trackingNumber = "TRX-449102",
                    createdAt = System.currentTimeMillis() - 28800000L
                )
            )
            for (sample in sampleOrders) {
                orderDao.insertOrder(sample)
            }
        }
    }
}
