package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.EggAlt
import androidx.compose.material.icons.filled.EmojiFoodBeverage
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.EmeraldPrimary

data class CategoryItem(val name: String, val icon: ImageVector)

val FoodCategories = listOf(
    CategoryItem("All", Icons.Default.Fastfood),
    CategoryItem("Desi Ghee & Oils", Icons.Default.WaterDrop),
    CategoryItem("Honey & Sweeteners", Icons.Default.Eco),
    CategoryItem("Spices & Masalas", Icons.Default.LocalFireDepartment),
    CategoryItem("Dry Fruits & Nuts", Icons.Default.EggAlt),
    CategoryItem("Rice & Grains", Icons.Default.Grain),
    CategoryItem("Pickles & Chutneys", Icons.Default.Eco),
    CategoryItem("Traditional Sweets", Icons.Default.Fastfood),
    CategoryItem("Tea & Beverages", Icons.Default.EmojiFoodBeverage)
)

@Composable
fun CategoryFilterRow(
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FoodCategories.forEach { cat ->
            val isSelected = selectedCategory.equals(cat.name, ignoreCase = true)
            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelected(cat.name) },
                label = { Text(cat.name) },
                leadingIcon = {
                    Icon(
                        imageVector = if (isSelected) Icons.Default.Check else cat.icon,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                shape = RoundedCornerShape(20.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldPrimary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier.testTag("filter_chip_${cat.name.replace(" ", "_")}")
            )
        }
    }
}
