package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.StoreConfigEntity
import com.example.ui.components.AddEditProductDialog
import com.example.ui.components.DispatchOrderDialog
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SaffronSecondary
import com.example.ui.theme.SpiceAccent
import com.example.ui.theme.StatusCancelled
import com.example.ui.theme.StatusDelivered
import com.example.ui.theme.StatusDispatched
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusProcessing
import com.example.ui.viewmodel.AdminDashboardStats
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScreen(
    isAuthenticated: Boolean,
    dashboardStats: AdminDashboardStats,
    products: List<ProductEntity>,
    orders: List<OrderEntity>,
    storeConfig: StoreConfigEntity,
    selectedFilter: String,
    editingProduct: ProductEntity?,
    isAddProductOpen: Boolean,
    selectedOrderForDispatch: OrderEntity?,
    onVerifyPin: (String) -> Boolean,
    onLogout: () -> Unit,
    onFilterChange: (String) -> Unit,
    onOpenAddProduct: (Boolean) -> Unit,
    onSetEditingProduct: (ProductEntity?) -> Unit,
    onSaveProduct: (ProductEntity) -> Unit,
    onToggleStock: (ProductEntity) -> Unit,
    onDeleteProduct: (Long, String) -> Unit,
    onSetOrderForDispatch: (OrderEntity?) -> Unit,
    onDispatchOrder: (orderId: String, courier: String, tracking: String) -> Unit,
    onUpdateOrderStatus: (orderId: String, newStatus: String) -> Unit,
    onUpdateStoreConfig: (StoreConfigEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isAuthenticated) {
        AdminLoginView(onVerifyPin = onVerifyPin, modifier = modifier)
    } else {
        AdminDashboardView(
            dashboardStats = dashboardStats,
            products = products,
            orders = orders,
            storeConfig = storeConfig,
            selectedFilter = selectedFilter,
            onLogout = onLogout,
            onFilterChange = onFilterChange,
            onOpenAddProduct = onOpenAddProduct,
            onSetEditingProduct = onSetEditingProduct,
            onToggleStock = onToggleStock,
            onDeleteProduct = onDeleteProduct,
            onSetOrderForDispatch = onSetOrderForDispatch,
            onUpdateOrderStatus = onUpdateOrderStatus,
            onUpdateStoreConfig = onUpdateStoreConfig,
            modifier = modifier
        )
    }

    // Add or Edit Product Dialog
    if (isAddProductOpen) {
        AddEditProductDialog(
            initialProduct = editingProduct,
            onDismiss = { onOpenAddProduct(false) },
            onSaveProduct = onSaveProduct
        )
    }

    // Dispatch Order Dialog
    if (selectedOrderForDispatch != null) {
        DispatchOrderDialog(
            order = selectedOrderForDispatch,
            onDismiss = { onSetOrderForDispatch(null) },
            onConfirmDispatch = onDispatchOrder
        )
    }
}

@Composable
fun AdminLoginView(
    onVerifyPin: (String) -> Boolean,
    modifier: Modifier = Modifier
) {
    var pinText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(EmeraldDark)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(EmeraldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Admin Control Panel",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = EmeraldDark
                )

                Text(
                    text = "Khalfan Food Store Management",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = pinText,
                    onValueChange = {
                        if (it.length <= 6) {
                            pinText = it
                            errorMessage = null
                        }
                    },
                    label = { Text("Store Passcode / PIN") },
                    placeholder = { Text("Enter PIN (Default: 1234)") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    isError = errorMessage != null,
                    supportingText = if (errorMessage != null) {
                        { Text(errorMessage!!, color = MaterialTheme.colorScheme.error) }
                    } else {
                        { Text("Hint: Default PIN is 1234") }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_pin_input")
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val ok = onVerifyPin(pinText)
                        if (!ok) {
                            errorMessage = "Incorrect PIN. Try 1234."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("admin_login_submit_btn")
                ) {
                    Text(
                        text = "Access Admin Control",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AdminDashboardView(
    dashboardStats: AdminDashboardStats,
    products: List<ProductEntity>,
    orders: List<OrderEntity>,
    storeConfig: StoreConfigEntity,
    selectedFilter: String,
    onLogout: () -> Unit,
    onFilterChange: (String) -> Unit,
    onOpenAddProduct: (Boolean) -> Unit,
    onSetEditingProduct: (ProductEntity?) -> Unit,
    onToggleStock: (ProductEntity) -> Unit,
    onDeleteProduct: (Long, String) -> Unit,
    onSetOrderForDispatch: (OrderEntity?) -> Unit,
    onUpdateOrderStatus: (orderId: String, newStatus: String) -> Unit,
    onUpdateStoreConfig: (StoreConfigEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Overview", "Orders (${orders.size})", "Products (${products.size})", "Store Settings")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            Surface(
                color = EmeraldPrimary,
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Admin Control Panel",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "Khalfan Food Pakistan",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier.testTag("admin_logout_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout",
                                tint = Color.White
                            )
                        }
                    }

                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = EmeraldPrimary,
                        contentColor = Color.White,
                        edgePadding = 12.dp
                    ) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = {
                                    Text(
                                        text = title,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                }
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == 2) { // Products Tab
                FloatingActionButton(
                    onClick = { onOpenAddProduct(true) },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("admin_add_product_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Food Item")
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> AdminOverviewTab(
                    stats = dashboardStats,
                    recentOrders = orders.take(5),
                    onGoToOrders = { selectedTab = 1 },
                    onGoToProducts = { selectedTab = 2 },
                    onSetOrderForDispatch = onSetOrderForDispatch
                )
                1 -> AdminOrdersTab(
                    orders = orders,
                    selectedFilter = selectedFilter,
                    onFilterChange = onFilterChange,
                    onSetOrderForDispatch = onSetOrderForDispatch,
                    onUpdateOrderStatus = onUpdateOrderStatus
                )
                2 -> AdminProductsTab(
                    products = products,
                    onToggleStock = onToggleStock,
                    onEditProduct = onSetEditingProduct,
                    onDeleteProduct = onDeleteProduct,
                    onAddNew = { onOpenAddProduct(true) }
                )
                3 -> AdminSettingsTab(
                    currentConfig = storeConfig,
                    onSaveConfig = onUpdateStoreConfig
                )
            }
        }
    }
}

@Composable
fun AdminOverviewTab(
    stats: AdminDashboardStats,
    recentOrders: List<OrderEntity>,
    onGoToOrders: () -> Unit,
    onGoToProducts: () -> Unit,
    onSetOrderForDispatch: (OrderEntity) -> Unit
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Store Performance",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Stats Grid Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminStatCard(
                    title = "Total Sales",
                    value = "Rs. ${numberFormat.format(stats.totalRevenue.toInt())}",
                    icon = Icons.Default.Payments,
                    color = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Total Orders",
                    value = "${stats.totalOrders}",
                    icon = Icons.Default.ShoppingBag,
                    color = SaffronSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AdminStatCard(
                    title = "Pending Shipments",
                    value = "${stats.pendingDeliveries}",
                    icon = Icons.Default.PendingActions,
                    color = SpiceAccent,
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Active Products",
                    value = "${stats.totalProducts}",
                    icon = Icons.Default.Inventory2,
                    color = EmeraldDark,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Shortcuts
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Quick Management Shortcuts",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onGoToOrders,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Process Orders", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = onGoToProducts,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Manage Catalog", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Recent Orders Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Orders",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                TextButton(onClick = onGoToOrders) {
                    Text("View All", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Recent Orders List
        items(recentOrders, key = { it.orderId }) { order ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = order.orderId,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${order.customerCity}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = order.customerName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Rs. ${numberFormat.format(order.grandTotal.toInt())} (${order.paymentMethod})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (order.status == "Pending" || order.status == "Processing") {
                        Button(
                            onClick = { onSetOrderForDispatch(order) },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronSecondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Dispatch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = order.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = EmeraldDark
            )
        }
    }
}

@Composable
fun AdminOrdersTab(
    orders: List<OrderEntity>,
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    onSetOrderForDispatch: (OrderEntity) -> Unit,
    onUpdateOrderStatus: (orderId: String, newStatus: String) -> Unit
) {
    val filters = listOf("All", "Pending", "Processing", "Dispatched", "Delivered", "Cancelled")
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)
    val context = LocalContext.current
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    Column(modifier = Modifier.fillMaxSize()) {
        // Status Filter Chips
        ScrollableTabRow(
            selectedTabIndex = filters.indexOf(selectedFilter).coerceAtLeast(0),
            containerColor = MaterialTheme.colorScheme.surface,
            edgePadding = 12.dp
        ) {
            filters.forEach { filter ->
                Tab(
                    selected = selectedFilter == filter,
                    onClick = { onFilterChange(filter) },
                    text = { Text(filter, fontSize = 12.sp) }
                )
            }
        }

        if (orders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No orders found in '$selectedFilter'",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(orders, key = { it.orderId }) { order ->
                    var statusMenuOpen by remember { mutableStateOf(false) }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_order_card_${order.orderId}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Top Info
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = order.orderId,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = EmeraldPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = dateFormat.format(Date(order.createdAt)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Status Pill with dropdown
                                Box {
                                    Surface(
                                        color = when (order.status) {
                                            "Pending" -> StatusPending.copy(alpha = 0.15f)
                                            "Processing" -> StatusProcessing.copy(alpha = 0.15f)
                                            "Dispatched" -> StatusDispatched.copy(alpha = 0.15f)
                                            "Delivered" -> StatusDelivered.copy(alpha = 0.15f)
                                            else -> StatusCancelled.copy(alpha = 0.15f)
                                        },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        TextButton(onClick = { statusMenuOpen = true }) {
                                            Text(
                                                text = "${order.status} ▼",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = statusMenuOpen,
                                        onDismissRequest = { statusMenuOpen = false }
                                    ) {
                                        listOf("Pending", "Processing", "Delivered", "Cancelled").forEach { st ->
                                            DropdownMenuItem(
                                                text = { Text("Set $st") },
                                                onClick = {
                                                    onUpdateOrderStatus(order.orderId, st)
                                                    statusMenuOpen = false
                                                }
                                            )
                                        }
                                        DropdownMenuItem(
                                            text = { Text("Dispatch via Courier...") },
                                            onClick = {
                                                onSetOrderForDispatch(order)
                                                statusMenuOpen = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Customer Details & Phone
                            Text(
                                text = "${order.customerName} • ${order.customerCity}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Address: ${order.customerAddress}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (order.specialNotes.isNotBlank()) {
                                Text(
                                    text = "Notes: ${order.specialNotes}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SaffronSecondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(8.dp))

                            // Items
                            Text(
                                text = "Items: ${order.itemsSummary}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )

                            // Courier details if dispatched
                            if (order.courierName.isNotBlank() || order.trackingNumber.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Courier: ${order.courierName} (${order.trackingNumber})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Bottom actions (Call, WhatsApp, Dispatch)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Rs. ${numberFormat.format(order.grandTotal.toInt())} (${order.paymentMethod})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = EmeraldDark
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Call Customer
                                    IconButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.customerPhone}"))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {}
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Call, contentDescription = "Call", tint = EmeraldPrimary)
                                    }

                                    // WhatsApp Customer
                                    IconButton(
                                        onClick = {
                                            try {
                                                val clean = order.customerPhone.replace("-", "").replace(" ", "").let {
                                                    if (it.startsWith("0")) "+92" + it.substring(1) else it
                                                }
                                                val msg = "Assalam o Alaikum ${order.customerName}! This is Khalfan Food regarding your Order #${order.orderId}."
                                                val url = "https://api.whatsapp.com/send?phone=$clean&text=${Uri.encode(msg)}"
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {}
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Outlined.Chat, contentDescription = "WhatsApp", tint = EmeraldPrimary)
                                    }

                                    if (order.status != "Dispatched" && order.status != "Delivered") {
                                        Button(
                                            onClick = { onSetOrderForDispatch(order) },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaffronSecondary),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Dispatch", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminProductsTab(
    products: List<ProductEntity>,
    onToggleStock: (ProductEntity) -> Unit,
    onEditProduct: (ProductEntity) -> Unit,
    onDeleteProduct: (Long, String) -> Unit,
    onAddNew: () -> Unit
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale.US)
    var productToDelete by remember { mutableStateOf<ProductEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Store Catalog (${products.size} Products)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Button(
                onClick = onAddNew,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Item", fontSize = 12.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(products, key = { it.id }) { product ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = product.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (product.isFeatured) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = SaffronSecondary,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "FEATURED",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "${product.category} • ${product.weightUnit}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = "Rs. ${numberFormat.format(product.price.toInt())} | Stock: ${product.stockQuantity}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldPrimary
                            )
                        }

                        // In Stock Toggle
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (product.inStock) "In Stock" else "Out",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (product.inStock) EmeraldPrimary else Color.Gray
                            )
                            Switch(
                                checked = product.inStock,
                                onCheckedChange = { onToggleStock(product) },
                                colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary),
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Edit Button
                        IconButton(
                            onClick = { onEditProduct(product) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = EmeraldPrimary)
                        }

                        // Delete Button
                        IconButton(
                            onClick = { productToDelete = product },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    // Delete Confirmation
    if (productToDelete != null) {
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("Delete '${productToDelete!!.name}'?") },
            text = { Text("Are you sure you want to remove this product from Khalfan Food catalog?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProduct(productToDelete!!.id, productToDelete!!.name)
                        productToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AdminSettingsTab(
    currentConfig: StoreConfigEntity,
    onSaveConfig: (StoreConfigEntity) -> Unit
) {
    var storeName by remember { mutableStateOf(currentConfig.storeName) }
    var deliveryFeeText by remember { mutableStateOf(currentConfig.deliveryFee.toInt().toString()) }
    var freeThresholdText by remember { mutableStateOf(currentConfig.freeDeliveryThreshold.toInt().toString()) }
    var announcement by remember { mutableStateOf(currentConfig.announcement) }
    var whatsapp by remember { mutableStateOf(currentConfig.whatsappNumber) }
    var adminPin by remember { mutableStateOf(currentConfig.adminPin) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Store Delivery Configuration",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = deliveryFeeText,
                        onValueChange = { deliveryFeeText = it },
                        label = { Text("Standard Delivery Fee Across Pakistan (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = freeThresholdText,
                        onValueChange = { freeThresholdText = it },
                        label = { Text("Free Delivery Minimum Order (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Store Information & Support",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it },
                        label = { Text("Store Display Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = whatsapp,
                        onValueChange = { whatsapp = it },
                        label = { Text("Customer Support WhatsApp Number") },
                        placeholder = { Text("+923123456789") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = announcement,
                        onValueChange = { announcement = it },
                        label = { Text("Homepage Announcement Ticker") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Security & Admin Access",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = adminPin,
                        onValueChange = { adminPin = it },
                        label = { Text("Admin Passcode / PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    val updated = currentConfig.copy(
                        storeName = storeName.trim(),
                        deliveryFee = deliveryFeeText.toDoubleOrNull() ?: 250.0,
                        freeDeliveryThreshold = freeThresholdText.toDoubleOrNull() ?: 3000.0,
                        announcement = announcement.trim(),
                        whatsappNumber = whatsapp.trim(),
                        adminPin = adminPin.trim().ifBlank { "1234" }
                    )
                    onSaveConfig(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("admin_save_settings_btn")
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Store Settings", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}
