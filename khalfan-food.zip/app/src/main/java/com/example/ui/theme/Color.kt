package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Khalfan Food - Pakistani Food Store Palette
// Deep Forest / Emerald Greens (Halal, Pure, Organic)
val EmeraldPrimary = Color(0xFF13503B)
val EmeraldLight = Color(0xFF1B6B50)
val EmeraldDark = Color(0xFF0C3325)
val EmeraldContainer = Color(0xFFD4EDE2)
val OnEmeraldContainer = Color(0xFF042116)

// Saffron Gold & Honey Amber
val SaffronSecondary = Color(0xFFD97706)
val SaffronLight = Color(0xFFF59E0B)
val SaffronContainer = Color(0xFFFEF3C7)
val OnSaffronContainer = Color(0xFF78350F)

// Rich Spice & Terracotta Accents
val SpiceAccent = Color(0xFFDC2626)
val SpiceContainer = Color(0xFFFEE2E2)

// Warm Backgrounds & Neutrals
val IvoryBackground = Color(0xFFFBF9F5)
val PureWhiteSurface = Color(0xFFFFFFFF)
val WarmCardBackground = Color(0xFFF5F2EB)
val TextDark = Color(0xFF1F2937)
val TextMuted = Color(0xFF6B7280)
val DividerColor = Color(0xFFE5E7EB)

// Status colors
val StatusPending = Color(0xFFD97706)
val StatusProcessing = Color(0xFF2563EB)
val StatusDispatched = Color(0xFF7C3AED)
val StatusDelivered = Color(0xFF16A34A)
val StatusCancelled = Color(0xFFDC2626)

// Dark Theme Colors
val EmeraldPrimaryDark = Color(0xFF5ED6A4)
val EmeraldContainerDark = Color(0xFF144D37)
val DarkBackground = Color(0xFF121815)
val DarkSurface = Color(0xFF1C2420)
val DarkCard = Color(0xFF242E2A)
val DarkText = Color(0xFFF3F4F6)
val DarkTextMuted = Color(0xFF9CA3AF)
