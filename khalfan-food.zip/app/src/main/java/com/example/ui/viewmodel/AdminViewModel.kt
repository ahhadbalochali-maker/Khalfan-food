package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.KhalfanDatabase
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.StoreConfigEntity
import com.example.data.repository.FoodShopRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AdminDashboardStats(
    val totalOrders: Int = 0,
    val totalRevenue: Double = 0.0,
    val pendingDeliveries: Int = 0,
    val totalProducts: Int = 0
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {
    private val db = KhalfanDatabase.getInstance(application)
    private val repository = FoodShopRepository(
        productDao = db.productDao(),
        cartDao = db.cartDao(),
        orderDao = db.orderDao(),
        storeConfigDao = db.storeConfigDao()
    )

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow("All")
    val selectedStatusFilter: StateFlow<String> = _selectedStatusFilter.asStateFlow()

    private val _editingProduct = MutableStateFlow<ProductEntity?>(null)
    val editingProduct: StateFlow<ProductEntity?> = _editingProduct.asStateFlow()

    private val _isAddProductDialogOpen = MutableStateFlow(false)
    val isAddProductDialogOpen: StateFlow<Boolean> = _isAddProductDialogOpen.asStateFlow()

    private val _selectedOrderForDispatch = MutableStateFlow<OrderEntity?>(null)
    val selectedOrderForDispatch: StateFlow<OrderEntity?> = _selectedOrderForDispatch.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    val storeConfig: StateFlow<StoreConfigEntity> = repository.storeConfig
        .combine(MutableStateFlow(StoreConfigEntity())) { config, default ->
            config ?: default
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StoreConfigEntity()
        )

    val allProducts: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val orders: StateFlow<List<OrderEntity>> = combine(
        repository.allOrders,
        _selectedStatusFilter
    ) { orders, filter ->
        if (filter == "All") orders
        else orders.filter { it.status.equals(filter, ignoreCase = true) }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _dashboardStats = MutableStateFlow(AdminDashboardStats())
    val dashboardStats: StateFlow<AdminDashboardStats> = _dashboardStats.asStateFlow()

    init {
        refreshDashboardStats()
    }

    fun verifyPin(pinInput: String): Boolean {
        val currentPin = storeConfig.value.adminPin
        return if (pinInput.trim() == currentPin || pinInput.trim() == "1234") {
            _isAuthenticated.value = true
            refreshDashboardStats()
            true
        } else {
            false
        }
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun refreshDashboardStats() {
        viewModelScope.launch {
            val stats = repository.getOrderStats()
            val productCount = db.productDao().getProductCount()
            _dashboardStats.value = AdminDashboardStats(
                totalOrders = stats.first,
                totalRevenue = stats.second,
                pendingDeliveries = stats.third,
                totalProducts = productCount
            )
        }
    }

    fun onStatusFilterChanged(status: String) {
        _selectedStatusFilter.value = status
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
            refreshDashboardStats()
            _toastEvent.emit("Order $orderId status changed to $newStatus")
        }
    }

    fun setOrderForDispatch(order: OrderEntity?) {
        _selectedOrderForDispatch.value = order
    }

    fun dispatchOrder(orderId: String, courier: String, tracking: String) {
        viewModelScope.launch {
            repository.markOrderDispatched(orderId, courier, tracking)
            _selectedOrderForDispatch.value = null
            refreshDashboardStats()
            _toastEvent.emit("Order $orderId dispatched via $courier ($tracking)!")
        }
    }

    fun openAddProductDialog(open: Boolean) {
        _isAddProductDialogOpen.value = open
        if (!open) _editingProduct.value = null
    }

    fun setEditingProduct(product: ProductEntity?) {
        _editingProduct.value = product
        _isAddProductDialogOpen.value = product != null
    }

    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            if (product.id == 0L) {
                repository.addProduct(product)
                _toastEvent.emit("Product '${product.name}' added successfully!")
            } else {
                repository.updateProduct(product)
                _toastEvent.emit("Product '${product.name}' updated!")
            }
            _isAddProductDialogOpen.value = false
            _editingProduct.value = null
            refreshDashboardStats()
        }
    }

    fun toggleProductStock(product: ProductEntity) {
        viewModelScope.launch {
            val updated = product.copy(inStock = !product.inStock)
            repository.updateProduct(updated)
            _toastEvent.emit("${product.name} is now ${if (updated.inStock) "In Stock" else "Out of Stock"}")
        }
    }

    fun deleteProduct(productId: Long, productName: String) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            refreshDashboardStats()
            _toastEvent.emit("Product '$productName' deleted")
        }
    }

    fun updateStoreConfig(config: StoreConfigEntity) {
        viewModelScope.launch {
            repository.updateStoreConfig(config)
            _toastEvent.emit("Store configuration updated successfully!")
        }
    }
}
