package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.KhalfanDatabase
import com.example.data.model.CartItemWithProduct
import com.example.data.model.OrderEntity
import com.example.data.model.ProductEntity
import com.example.data.model.StoreConfigEntity
import com.example.data.repository.FoodShopRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class ProductSortOption(val label: String) {
    FEATURED("Featured"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low"),
    RATING("Top Rated")
}

class ShopViewModel(application: Application) : AndroidViewModel(application) {
    private val db = KhalfanDatabase.getInstance(application)
    val repository = FoodShopRepository(
        productDao = db.productDao(),
        cartDao = db.cartDao(),
        orderDao = db.orderDao(),
        storeConfigDao = db.storeConfigDao()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _sortOption = MutableStateFlow(ProductSortOption.FEATURED)
    val sortOption: StateFlow<ProductSortOption> = _sortOption.asStateFlow()

    private val _selectedProduct = MutableStateFlow<ProductEntity?>(null)
    val selectedProduct: StateFlow<ProductEntity?> = _selectedProduct.asStateFlow()

    private val _isCheckoutOpen = MutableStateFlow(false)
    val isCheckoutOpen: StateFlow<Boolean> = _isCheckoutOpen.asStateFlow()

    private val _placedOrder = MutableStateFlow<OrderEntity?>(null)
    val placedOrder: StateFlow<OrderEntity?> = _placedOrder.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    val storeConfig: StateFlow<StoreConfigEntity> = repository.storeConfig
        .combine(MutableStateFlow(StoreConfigEntity())) { config, default ->
            config ?: default
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StoreConfigEntity()
        )

    val cartItems: StateFlow<List<CartItemWithProduct>> = repository.cartItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered & sorted products
    val displayedProducts: StateFlow<List<ProductEntity>> = combine(
        repository.allProducts,
        _searchQuery,
        _selectedCategory,
        _sortOption
    ) { products, query, category, sort ->
        var filtered = products

        if (category != "All") {
            filtered = filtered.filter { it.category.equals(category, ignoreCase = true) }
        }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            filtered = filtered.filter {
                it.name.lowercase().contains(q) ||
                        it.description.lowercase().contains(q) ||
                        it.category.lowercase().contains(q)
            }
        }

        when (sort) {
            ProductSortOption.FEATURED -> filtered.sortedByDescending { it.isFeatured }
            ProductSortOption.PRICE_LOW_HIGH -> filtered.sortedBy { it.price }
            ProductSortOption.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.price }
            ProductSortOption.RATING -> filtered.sortedByDescending { it.rating }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        viewModelScope.launch {
            repository.prepopulateIfNeeded()
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
    }

    fun onSortOptionChanged(option: ProductSortOption) {
        _sortOption.value = option
    }

    fun onProductSelected(product: ProductEntity?) {
        _selectedProduct.value = product
    }

    fun addToCart(product: ProductEntity, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(product.id, quantity)
            _toastEvent.emit("${product.name} added to cart!")
        }
    }

    fun updateCartQuantity(cartId: Long, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartId, newQuantity)
        }
    }

    fun removeFromCart(cartId: Long) {
        viewModelScope.launch {
            repository.removeFromCart(cartId)
            _toastEvent.emit("Item removed from cart")
        }
    }

    fun openCheckout(open: Boolean) {
        _isCheckoutOpen.value = open
    }

    fun dismissOrderConfirmation() {
        _placedOrder.value = null
    }

    fun placeOrder(
        name: String,
        phone: String,
        city: String,
        address: String,
        notes: String,
        paymentMethod: String
    ) {
        viewModelScope.launch {
            val currentCart = cartItems.value
            if (currentCart.isEmpty()) {
                _toastEvent.emit("Your cart is empty!")
                return@launch
            }

            val itemsSubtotal = currentCart.sumOf { it.product.price * it.quantity }
            val config = repository.getStoreConfigSync()
            val deliveryFee = if (itemsSubtotal >= config.freeDeliveryThreshold) 0.0 else config.deliveryFee
            val grandTotal = itemsSubtotal + deliveryFee

            val itemsSummary = currentCart.joinToString(", ") {
                "${it.product.name} (${it.product.weightUnit}) x ${it.quantity}"
            }

            val randomNum = Random.nextInt(1000, 9999)
            val newOrderId = "KF-$randomNum"

            val order = OrderEntity(
                orderId = newOrderId,
                customerName = name.trim(),
                customerPhone = phone.trim(),
                customerCity = city.trim(),
                customerAddress = address.trim(),
                specialNotes = notes.trim(),
                itemsSummary = itemsSummary,
                itemsTotal = itemsSubtotal,
                deliveryFee = deliveryFee,
                grandTotal = grandTotal,
                paymentMethod = paymentMethod,
                status = "Pending",
                createdAt = System.currentTimeMillis()
            )

            repository.placeOrder(order)
            repository.clearCart()
            _isCheckoutOpen.value = false
            _placedOrder.value = order
            _toastEvent.emit("Order $newOrderId placed successfully! Shukriya for shopping with Khalfan Food.")
        }
    }
}
